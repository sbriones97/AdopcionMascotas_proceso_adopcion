const routesSeguimiento = require('./seguimiento')
const routesProceso = require('./proceso')

module.exports = {
    routesSeguimiento,
    routesProceso
}