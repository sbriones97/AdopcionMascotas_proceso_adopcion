- Descripción del micro-servicio: Se encargará de cuidar el proceso de adopción entre cada usuario para que siempre se mantengan enterados del status

- Requerimientos funcionales: Token de autenticación, status de proceso, notificaciones del proceso, opciones para subir documentación e información requerida

- Requerimientos no funcionales: procurar la respuesta rápida de los usuarios, mensajes de advertencia y de exito, opción de distintos tipos de notificaciones

- URL de despliegue: